import { Phone, AlertCircle } from "lucide-react";
import { Button } from "@/components/ui/button";

export default function EmergencyBanner() {
  return (
    <section className="py-16 px-6 bg-destructive text-destructive-foreground" data-testid="section-emergency">
      <div className="max-w-5xl mx-auto text-center">
        <div className="flex justify-center mb-4">
          <AlertCircle className="h-12 w-12" />
        </div>
        <h2 className="text-3xl md:text-4xl lg:text-5xl font-bold mb-4">
          24/7 Emergency Plumbing Services
        </h2>
        <p className="text-lg md:text-xl mb-8 text-destructive-foreground/90">
          Plumbing emergency? We're here for you day or night. Fast response times to minimize damage and get your system running again.
        </p>
        <Button 
          size="lg" 
          className="text-lg px-8 py-6 bg-white text-destructive hover:bg-white/90"
          data-testid="button-emergency-call"
        >
          <Phone className="mr-2 h-5 w-5" />
          Emergency Call: (719) 406-7517
        </Button>
        <p className="mt-4 text-sm text-destructive-foreground/80">
          Average response time: Under 60 minutes
        </p>
      </div>
    </section>
  );
}
