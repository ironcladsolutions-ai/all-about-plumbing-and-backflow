import { Phone, Mail, MapPin } from "lucide-react";
import { Badge } from "@/components/ui/badge";

const quickLinks = [
  "General Plumbing",
  "Backflow Testing",
  "Faucet Repair",
  "Sewer Line Replacement",
  "Commercial Services",
  "Emergency Services",
];

const serviceAreas = [
  "Downtown Pueblo",
  "Pueblo West",
  "Belmont",
  "Bessemer",
  "Pueblo County",
];

export default function Footer() {
  return (
    <footer className="bg-card border-t border-card-border" data-testid="footer">
      <div className="max-w-7xl mx-auto px-6 py-16">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12">
          <div>
            <h3 className="text-xl font-bold mb-4">
              All About Plumbing<br />and Backflow
            </h3>
            <Badge 
              variant="secondary" 
              className="mb-4 bg-primary/10 text-primary border-primary/20"
            >
              🇺🇸 Veteran-Owned
            </Badge>
            <p className="text-muted-foreground text-sm">
              Professional plumbing services serving Pueblo, CO with integrity and excellence since 2010.
            </p>
          </div>
          
          <div>
            <h4 className="font-semibold mb-4">Services</h4>
            <ul className="space-y-2">
              {quickLinks.map((link, index) => (
                <li key={index}>
                  <a 
                    href="#" 
                    className="text-sm text-muted-foreground hover:text-primary transition-colors"
                    data-testid={`link-service-${index}`}
                  >
                    {link}
                  </a>
                </li>
              ))}
            </ul>
          </div>
          
          <div>
            <h4 className="font-semibold mb-4">Service Areas</h4>
            <ul className="space-y-2">
              {serviceAreas.map((area, index) => (
                <li key={index} className="text-sm text-muted-foreground">
                  {area}
                </li>
              ))}
            </ul>
          </div>
          
          <div>
            <h4 className="font-semibold mb-4">Contact Info</h4>
            <ul className="space-y-3">
              <li className="flex items-start gap-2 text-sm">
                <Phone className="h-4 w-4 text-primary flex-shrink-0 mt-0.5" />
                <div>
                  <div className="font-medium">Phone</div>
                  <a href="tel:7194067517" className="text-muted-foreground hover:text-primary" data-testid="link-phone">
                    (719) 406-7517
                  </a>
                </div>
              </li>
              <li className="flex items-start gap-2 text-sm">
                <Mail className="h-4 w-4 text-primary flex-shrink-0 mt-0.5" />
                <div>
                  <div className="font-medium">Email</div>
                  <a href="mailto:virginiabozz@gmail.com" className="text-muted-foreground hover:text-primary" data-testid="link-email">
                    virginiabozz@gmail.com
                  </a>
                </div>
              </li>
              <li className="flex items-start gap-2 text-sm">
                <MapPin className="h-4 w-4 text-primary flex-shrink-0 mt-0.5" />
                <div>
                  <div className="font-medium">Location</div>
                  <div className="text-muted-foreground">
                    Pueblo, CO 81001
                  </div>
                </div>
              </li>
            </ul>
          </div>
        </div>
        
        <div className="border-t border-border mt-12 pt-8 text-center text-sm text-muted-foreground">
          <p>© {new Date().getFullYear()} All About Plumbing and Backflow. All rights reserved.</p>
          <p className="mt-2">Licensed & Insured | Master Plumber License #CO-03001082</p>
        </div>
      </div>
    </footer>
  );
}
