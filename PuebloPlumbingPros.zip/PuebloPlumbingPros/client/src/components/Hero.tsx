import { Phone, Calendar } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";

const heroImage = "/service-van.png";

export default function Hero() {
  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden">
      <div 
        className="absolute inset-0 bg-cover bg-center"
        style={{ backgroundImage: `url(${heroImage})` }}
      />
      <div className="absolute inset-0 bg-gradient-to-b from-black/70 via-black/60 to-black/70" />
      
      <div className="relative z-10 max-w-5xl mx-auto px-6 py-20 text-center">
        <Badge 
          variant="secondary" 
          className="mb-6 text-sm md:text-base bg-primary/20 backdrop-blur-sm border-primary/30 text-white hover:bg-primary/30"
          data-testid="badge-veteran-owned"
        >
          🇺🇸 Proudly Veteran-Owned
        </Badge>
        
        <h1 className="text-5xl md:text-6xl lg:text-7xl font-bold text-white mb-6">
          All About Plumbing<br />and Backflow
        </h1>
        
        <p className="text-xl md:text-2xl text-white/90 mb-8 max-w-3xl mx-auto">
          Professional plumbing services you can trust. Serving Pueblo, CO with integrity and expertise.
        </p>
        
        <div className="flex flex-col sm:flex-row gap-4 justify-center items-center mb-8">
          <Button 
            size="lg" 
            className="text-lg px-8 py-6 bg-primary border border-primary-border hover:bg-primary/90"
            data-testid="button-call-now"
          >
            <Phone className="mr-2 h-5 w-5" />
            Call Now: (719) 406-7517
          </Button>
          <Button 
            size="lg" 
            variant="outline" 
            className="text-lg px-8 py-6 bg-white/10 backdrop-blur-sm border-white/30 text-white hover:bg-white/20"
            data-testid="button-schedule"
          >
            <Calendar className="mr-2 h-5 w-5" />
            Schedule Service
          </Button>
        </div>
        
        <div className="flex flex-wrap justify-center gap-6 text-white/90 text-sm md:text-base">
          <span className="flex items-center gap-2">
            ⚡ 24/7 Emergency Service
          </span>
          <span className="flex items-center gap-2">
            ✓ Licensed & Insured
          </span>
          <span className="flex items-center gap-2">
            ⭐ Pueblo's Trusted Since 2010
          </span>
        </div>
      </div>
    </section>
  );
}
