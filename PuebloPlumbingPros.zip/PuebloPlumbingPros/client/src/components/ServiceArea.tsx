import { MapPin } from "lucide-react";
import { Badge } from "@/components/ui/badge";

const areas = [
  "Pueblo",
  "Colorado Springs",
  "La Junta",
  "Fountain",
  "Cañon City",
  "Walsenburg",
  "Rocky Ford",
  "Rye",
  "Fowler",
  "Manzanola",
  "Olney Springs",
  "Pueblo County",
  "Otero County",
  "Crowley County",
  "Fremont County",
  "Huerfano County",
];

export default function ServiceArea() {
  return (
    <section className="py-20 lg:py-24 px-6 bg-muted/30" data-testid="section-service-area">
      <div className="max-w-5xl mx-auto text-center">
        <div className="flex justify-center mb-6">
          <MapPin className="h-12 w-12 text-primary" />
        </div>
        <h2 className="text-4xl md:text-5xl font-bold mb-4">
          Proudly Serving Pueblo, CO
        </h2>
        <p className="text-lg md:text-xl text-muted-foreground mb-12 max-w-3xl mx-auto">
          As a local, veteran-owned business, we're committed to serving our community with the highest quality plumbing services.
        </p>
        
        <div className="flex flex-wrap justify-center gap-3 mb-8">
          {areas.map((area, index) => (
            <Badge 
              key={index} 
              variant="secondary" 
              className="text-base px-4 py-2"
              data-testid={`badge-area-${index}`}
            >
              {area}
            </Badge>
          ))}
        </div>
        
        <p className="text-muted-foreground">
          Don't see your area listed? <span className="text-primary font-semibold">Give us a call</span> - we may still be able to help!
        </p>
      </div>
    </section>
  );
}
