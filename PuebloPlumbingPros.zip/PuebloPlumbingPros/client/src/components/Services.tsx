import { Wrench, Droplets, Home, Building2, Shield, Gauge } from "lucide-react";
import { Card, CardHeader, CardTitle, CardDescription, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";

const services = [
  {
    icon: Wrench,
    title: "General Plumbing",
    description: "From leak repairs to fixture installations, we handle all your residential and commercial plumbing needs with expert precision.",
  },
  {
    icon: Gauge,
    title: "Backflow Testing & Certification",
    description: "State-certified backflow testing and prevention to keep your water supply safe and compliant with local regulations.",
  },
  {
    icon: Droplets,
    title: "Faucet & Fixture Repair",
    description: "Professional repair and replacement of faucets, sinks, toilets, and all plumbing fixtures with quality parts and workmanship.",
  },
  {
    icon: Home,
    title: "Sewer Line Replacement",
    description: "Expert sewer line inspection, repair, and replacement using modern techniques to minimize disruption to your property.",
  },
  {
    icon: Building2,
    title: "Commercial Plumbing",
    description: "Comprehensive commercial plumbing services for businesses, including maintenance programs and emergency response.",
  },
  {
    icon: Shield,
    title: "Emergency Services",
    description: "24/7 emergency plumbing services when you need us most. Fast response times to minimize damage and restore service.",
  },
];

export default function Services() {
  return (
    <section className="py-20 lg:py-24 px-6" data-testid="section-services">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold mb-4">
            Our Services
          </h2>
          <p className="text-lg md:text-xl text-muted-foreground max-w-3xl mx-auto">
            Comprehensive plumbing solutions for homes and businesses throughout Pueblo, CO
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {services.map((service, index) => (
            <Card 
              key={index} 
              className="hover-elevate active-elevate-2 transition-all"
              data-testid={`card-service-${index}`}
            >
              <CardHeader>
                <div className="w-12 h-12 bg-primary/10 rounded-md flex items-center justify-center mb-4">
                  <service.icon className="h-6 w-6 text-primary" />
                </div>
                <CardTitle className="text-xl md:text-2xl">
                  {service.title}
                </CardTitle>
              </CardHeader>
              <CardContent>
                <CardDescription className="text-base mb-4">
                  {service.description}
                </CardDescription>
                <Button 
                  variant="ghost" 
                  className="px-0 text-primary"
                  data-testid={`button-learn-more-${index}`}
                >
                  Learn More →
                </Button>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
}
