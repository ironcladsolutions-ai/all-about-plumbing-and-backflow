import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { CheckCircle } from "lucide-react";

const credentials = [
  "Colorado State Licensed Plumber",
  "Backflow Certification - Colorado Department of Health",
  "EPA Lead-Safe Certified",
  "OSHA Safety Certified",
  "Master Plumber - 15+ Years Experience",
  "United States Military Veteran",
];

export default function VeteranStory() {
  return (
    <section className="py-20 lg:py-24 px-6" data-testid="section-about">
      <div className="max-w-7xl mx-auto">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-12 items-start">
          <div className="lg:col-span-2 flex flex-col gap-12">
            <div>
              <Badge 
                variant="secondary" 
                className="mb-4 bg-primary/10 text-primary border-primary/20"
                data-testid="badge-about-veteran"
              >
                Veteran-Owned & Operated
              </Badge>
              <h2 className="text-4xl md:text-5xl font-bold mb-6">
                Serving Pueblo with Pride
              </h2>
              <div className="space-y-4 text-base md:text-lg text-muted-foreground">
                <p>
                  All About Plumbing and Backflow was founded on the principles learned through military service: integrity, dedication, and excellence. As a veteran-owned business, we bring the same commitment to our customers that we brought to serving our country.
                </p>
                <p>
                  With over 15 years of experience serving the Pueblo community, we've built our reputation one satisfied customer at a time. Our team is dedicated to providing honest, reliable service that you can count on.
                </p>
                <p>
                  We understand that plumbing emergencies don't wait for convenient times. That's why we're available 24/7 to serve you with the same rapid response and attention to detail that defined our military service.
                </p>
              </div>
            </div>
            
            <div>
              <h3 className="text-2xl font-semibold mb-4">Credentials & Certifications</h3>
              <div className="space-y-3">
                {credentials.map((credential, index) => (
                  <div 
                    key={index} 
                    className="flex items-start gap-3"
                    data-testid={`credential-${index}`}
                  >
                    <CheckCircle className="h-5 w-5 text-primary flex-shrink-0 mt-0.5" />
                    <span className="text-muted-foreground text-sm">{credential}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
          
          <div className="lg:col-span-1">
            <Card className="overflow-hidden sticky top-32">
              <img 
                src="/owner.jpg" 
                alt="Veteran-owned plumbing business owner" 
                className="w-full h-auto object-cover"
                data-testid="img-owner"
              />
            </Card>
          </div>
        </div>
      </div>
    </section>
  );
}
