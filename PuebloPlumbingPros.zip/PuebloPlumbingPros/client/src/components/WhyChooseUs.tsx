import { Award, Clock, ThumbsUp, Users } from "lucide-react";

const features = [
  {
    icon: Award,
    title: "Licensed & Certified",
    description: "Fully licensed, insured, and certified technicians with ongoing training",
  },
  {
    icon: Clock,
    title: "24/7 Availability",
    description: "Emergency services available around the clock when you need us most",
  },
  {
    icon: ThumbsUp,
    title: "Satisfaction Guaranteed",
    description: "We stand behind our work with a 100% satisfaction guarantee",
  },
  {
    icon: Users,
    title: "Veteran-Owned",
    description: "Military values of integrity, discipline, and service excellence",
  },
];

export default function WhyChooseUs() {
  return (
    <section className="py-20 lg:py-24 px-6 bg-muted/30" data-testid="section-why-choose">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold mb-4">
            Why Choose Us
          </h2>
          <p className="text-lg md:text-xl text-muted-foreground max-w-3xl mx-auto">
            Experience the difference of working with Pueblo's most trusted plumbing professionals
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {features.map((feature, index) => (
            <div 
              key={index} 
              className="text-center"
              data-testid={`feature-${index}`}
            >
              <div className="w-16 h-16 bg-primary/10 rounded-md flex items-center justify-center mx-auto mb-4">
                <feature.icon className="h-8 w-8 text-primary" />
              </div>
              <h3 className="text-xl font-semibold mb-2">
                {feature.title}
              </h3>
              <p className="text-muted-foreground">
                {feature.description}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
