import EmergencyBanner from '../EmergencyBanner'

export default function EmergencyBannerExample() {
  return <EmergencyBanner />
}
