import ServiceArea from '../ServiceArea'

export default function ServiceAreaExample() {
  return <ServiceArea />
}
