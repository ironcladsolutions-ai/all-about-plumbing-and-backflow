import VeteranStory from '../VeteranStory'

export default function VeteranStoryExample() {
  return <VeteranStory />
}
