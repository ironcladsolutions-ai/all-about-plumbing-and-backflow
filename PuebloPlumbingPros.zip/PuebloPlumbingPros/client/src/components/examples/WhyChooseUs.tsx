import WhyChooseUs from '../WhyChooseUs'

export default function WhyChooseUsExample() {
  return <WhyChooseUs />
}
